# 3 files in total
 
# 
set FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `#__ra_areas`;
DROP TABLE IF EXISTS `#__ra_clusters`
DROP TABLE IF EXISTS `#__ra_groups`;
DROP TABLE IF EXISTS `#__ra_nations`;
set FOREIGN_KEY_CHECKS=1;
