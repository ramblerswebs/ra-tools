<?php

namespace Ramblers\Component\ra_tools\Administrator\View\xxxx;

\defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;

//use Ramblers\Component\Ra_tools\Administrator\Helper\ToolsHelper;
class HtmlView extends BaseHtmlView {

}
