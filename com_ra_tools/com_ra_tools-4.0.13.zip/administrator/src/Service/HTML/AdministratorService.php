<?php

namespace Ramblers\Component\Ra_tools\Administrator\Service\HTML;

defined('JPATH_BASE') or die;

class AdministratorService {

}
